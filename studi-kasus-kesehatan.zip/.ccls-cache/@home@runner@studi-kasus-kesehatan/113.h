void Apotek::masuk() {
databarang db; 
  int aaaa;
  do{ 
    cout<<endl;
 	  cout<<"======================================================="<< endl;
    cout<<"                     MENU INPUT OBAT"<<endl;  
    cout<<"======================================================="<< endl;
    createDataSingle(" 4. Selesai");
    tambahAwalSingle(" 3. Tampil Data");
    tambahAwalSingle(" 2. Hapus Obat");
    tambahAwalSingle(" 1. Tambah Obat");
    tambahAwalSingle(" 1. Tambah Obat");
    deleteAwalSingle();
    printDataSingle();
    cout<<"======================================================="<< endl;
    cout << " Masukkan pilihan menu : " ; 
    cin >> aaaa; 
    cout << endl;
    switch (aaaa){
      case 1:	
				tambahDepanDouble();
				break;
			case 2:	
				hapusDepanDouble();
				break;
      case 3:
				printDataDouble();
				break;
      case 4:
        loginsatu();
        break;
      }    	
	} while (aaaa != 8);
}
  
